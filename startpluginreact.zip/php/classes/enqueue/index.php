<?php
// May Allah Guide You To The Right Path. Ameen